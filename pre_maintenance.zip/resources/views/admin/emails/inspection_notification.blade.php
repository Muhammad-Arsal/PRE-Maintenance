<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>{{ $subject }}</title>
</head>
<body>
  {!! $bodyHtml !!}
</body>
</html>
